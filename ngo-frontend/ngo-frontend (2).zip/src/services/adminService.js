export async function adminLogin(formData) {
  try {
    const response = await fetch("http://localhost:5000/adminLogin", {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
      body: JSON.stringify(formData),
    });
    const data = await response.json();

    if (data.token) {
      localStorage.setItem("token", "Bearer "+data.token);
      localStorage.setItem("email", formData.email);
    }
    return data;
  } catch (error) {
    console.log(error);
  }
}

export async function updatePasswordOfAdmin(formData) {
  try {
    const token = localStorage.getItem("token"); 
    const response = await fetch(
      "http://localhost:5000/updatePasswordOfAdmin",
      {
        method: "PUT",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
          "Authorization": token
        },
        body: JSON.stringify(formData),
      }
    );
    const data = await response.json();
    return { status: response.status, data };
  } catch (error) {
    console.log(error);
  }
}


export async function getAllAdminData() {
  try {
    const token = localStorage.getItem("token"); 
    const response = await fetch("http://localhost:5000/getAllAdminData", {
      method: "GET",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: token ? token : "", 
      },
    });

    if (!response.ok) {
      console.error("Server responded with:", response.status);
      return [];
    }

    const data = await response.json();
    return Array.isArray(data) ? data : [];
  } catch (error) {
    console.log(error);
    return [];
  }
}
